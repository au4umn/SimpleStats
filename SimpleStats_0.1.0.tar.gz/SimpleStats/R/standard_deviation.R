#' Calculate the standard deviation of a numeric vector.
#'
#' This function calculates the standard deviation of a numeric vector.
#'
#' @param x A numeric vector for which the standard deviation is calculated.
#' @return The standard deviation value of the input numeric vector.
#' @examples
#' data <- c(10, 20, 30, 40, 50)
#' sd_value <- my_standard_deviation(data)
#' print(sd_value)
#'
#' @export
my_standard_deviation <- function(x) {
  sd_value <- sd(x)
  return(sd_value)
}