#' Calculate the variance of a numeric vector.
#'
#' This function calculates the variance of a numeric vector.
#'
#' @param x A numeric vector for which the variance is calculated.
#' @return The variance value of the input numeric vector.
#' @examples
#' data <- c(10, 20, 30, 40, 50)
#' variance_value <- my_variance(data)
#' print(variance_value)
#'
#' @export
my_variance <- function(x) {
  variance_value <- var(x)
  return(variance_value)
}