#' Calculate the median of a numeric vector.
#'
#' This function calculates the median value of a numeric vector.
#'
#' @param x A numeric vector for which the median is calculated.
#' @return The median value of the input numeric vector.
#' @examples
#' data <- c(10, 20, 30, 40, 50)
#' median_value <- my_median(data)
#' print(median_value)
#'
#' @export
my_median <- function(x) {
  median_value <- median(x)
  return(median_value)
}