#' Calculate the mean of a numeric vector.
#'
#' This function calculates the mean value of a numeric vector by summing all
#' the elements and dividing by the total number of elements.
#'
#' @param x A numeric vector for which the mean is calculated.
#' @return The mean value of the input numeric vector.
#' @examples
#' data <- c(10, 20, 30, 40, 50)
#' mean_value <- my_mean(data)
#' print(mean_value)
#'
#' @export
mean <- function(x) {
  mean_value <- sum(x) / length(x)
  return(mean_value)
}
